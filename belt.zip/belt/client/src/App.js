import './App.css';
import CreatePage from './views/CreatePage'
import DetailsPage from './views/DetailsPage'
import UpdatePage from './views/UpdatePage'
import Main from './views/Main';
import { Routes, Route, Link } from "react-router-dom"

function App() {
  return (
    <div className="App">
    
      <h1 style={{ borderBottom: '1px solid black', paddingBottom: '10px', borderTop: '1px solid black', paddingTop: '10px' }}>
        Store Finder
        </h1>
        
      <Link style={{margin:'10px'}} to="/">
        Go Home
        </Link>

      <Routes>
        <Route path="/" element={<Main />} />
        <Route path="/stores/new" element={<CreatePage />} />
        <Route path="/stores/:id" element={<DetailsPage />} />
        <Route path="/stores/:id/edit" element={<UpdatePage />} />
      </Routes>

    </div>
  );
}

export default App;
