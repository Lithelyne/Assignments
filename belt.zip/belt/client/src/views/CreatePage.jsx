import React from "react";
import { useNavigate } from "react-router-dom";

import CreateForm from "../components/CreateForm";

const CreatePage = () => {

    const navigate = useNavigate();
    return (
        <div>
            <h3>Add a new store!</h3>
            <CreateForm onCreate={() => navigate("/stores/:id")} />
        </div>
    )
}

export default CreatePage