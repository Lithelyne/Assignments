import React, { useEffect, useState } from 'react'
import axios from "axios"
import { useParams, useNavigate } from 'react-router-dom'


const UpdatePage = () => {
    const { id } = useParams()
    const [errors, setErrors] = useState([])
    const navigate = useNavigate();

    const [name, setName] = useState("")
    const [number, setNumber] = useState("")
    const [isOpen, setIsOpen] = useState(false)

    useEffect(() => {
        axios.get(`http://localhost:8000/api/stores/${id}`)
            .then(response => {
                const stores = response.data;
                setName(stores.name);
                setNumber(stores.number);
                setIsOpen(stores.isOpen);

            })
            .catch(err => console.log(err))
    }, [id])

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.patch(`http://localhost:8000/api/stores/${id}`, { name, number, isOpen })
            .then(response => {
                console.log(response.data)
                navigate(`/stores/${id}`)
            })
            .catch(err => {
                const errResponse = err.response.data.errors;
                const errMsgArr = []

                for (const eachKey in errResponse) {
                    errMsgArr.push(errResponse[eachKey]["message"])
                }
                setErrors(errMsgArr);
            })
    }

    

    return (
        <div>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Store Name:</label>
                    <input 
                    style={{ margin: '10px'}} type="text" 
                    name="name" value={name}
                    onChange={e => setName(e.target.value)} />
                </div>
                <div>
                    <label>Store Number:</label>
                    <input 
                    style={{ margin: '10px'}} type="text" 
                    name="number" 
                    value={number}
                    onChange={e => setNumber(e.target.value)} />
                </div>
                <div>
                    <label>Open:</label>
                    <input type="checkbox" 
                    name="isOpen" 
                    checked={isOpen} 
                    onChange={e => setIsOpen(e.target.checked)} />
                </div>
                <button style={{ margin:'10px'}} type="submit">
                    Edit Store
                </button>
                {
                    errors.map((eachErr, idx) => (
                        <p key={idx} style={{ color: "red" }}>
                            {eachErr}
                        </p>
                    ))
                }
            </form>
        </div>
    )
}

export default UpdatePage