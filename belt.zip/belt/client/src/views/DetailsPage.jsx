import React from "react";
import { useState, useEffect } from 'react';
import axios from "axios";
import { useParams, Link } from "react-router-dom";

const DetailsPage = () => {
    const [stores, setStores] = useState();

    const { id } = useParams();

    useEffect(() => {
        axios.get(`http://localhost:8000/api/stores/${id}`)
            .then(response => {
                setStores(response.data)
            })
            .catch(err => console.log(err))
    }, [id])

    return (
        <div>
            {
                stores ?
                    <div>
                        <h1> {stores.name} </h1>
                        <h3> Store Number: {stores.number} </h3>
                        {stores.isOpen ? <p>Open</p> : <p>Closed</p>}
                        <button>
                            <Link to={`/stores/${stores._id}/edit`}>
                                Edit Store Details
                            </Link>
                        </button>
                    </div> :
                    <h1>Loading..</h1>
            }
        </div>
    )
}

export default DetailsPage