import React from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const StoresTable = (props) => {
    const handleDelete = (deleteId) => {
        axios
            .delete(`http://localhost:8000/api/stores/${deleteId}`)
            .then((response) => {
                props.onDelete(deleteId);
            })
            .catch((err) => console.log(err));
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <table>
                <thead>
                    <tr>
                        <th>Store</th>
                        <th>Store Number</th>
                        <th>Open</th>
                        <th>Remove</th>
                    </tr>
                </thead>
                <tbody>
                    {props.storesList.map((eachStore, idx) => (
                        <tr key={idx}>
                            <td style={{ padding: '20px' }}>
                                <Link to={`/stores/${eachStore._id}`} style={{ marginLeft: '10px' }}>
                                    {eachStore.name}
                                </Link>
                            </td>
                            <td style={{ paddingRight: '20px' }}>
                                {eachStore.number}
                            </td>
                            <td style={{ paddingRight: '20px' }}>
                                {eachStore.isOpen ? <p>True</p> : <p>False</p>}
                            </td>
                            <td>
                                    <button onClick={() => handleDelete(eachStore._id)}>Delete</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default StoresTable;
