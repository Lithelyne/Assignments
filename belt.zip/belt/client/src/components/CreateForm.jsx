import React, { useState } from "react";
import axios from "axios"
import { useNavigate } from "react-router-dom";



const CreateForm = (props) => {
    const [name, setName] = useState("")
    const [number, setNumber] = useState("")
    const [isOpen, setIsOpen] = useState(false)

    const [errors, setErrors] = useState([])

    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        axios.post(`http://localhost:8000/api/stores`, { name, number, isOpen })
            .then(response => {
                props.onCreate(response.data)
                navigate(`/stores/${response.data._id}`); 
            })
            .catch(err => {
                const errResponse = err.response.data.errors;
                const errMsgArr = []

                for (const eachKey in errResponse) {
                    errMsgArr.push(errResponse[eachKey]["message"])
                }
                setErrors(errMsgArr);
            })
    }


    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
            <form onSubmit={handleSubmit}>
                <div style={{ display: 'flex', alignItems: 'center', margin: '10px 0' }}>
                    <label style={{ margin: '10px', width: '100px' }}>Store Name:</label>
                    <input
                        type="text"
                        name="name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}

                    />
                </div>
                <div style={{ display: 'flex', alignItems: 'center', margin: '10px 0' }}>
                    <label style={{ margin: '10px', width: '100px' }}>Store Number</label>
                    <input
                        type="text"
                        name="number"
                        value={number}
                        onChange={(e) => setNumber(e.target.value)}
                        style={{ marginBottom: '10px' }}
                    />
                </div>
                <div style={{ display: 'flex', alignItems: 'center', margin: '10px 0' }}>
                        <label style={{ margin: '10px', width: '100px' }}>
                            Open?
                        </label>
                    <input 
                        style={{ marginLeft: '10px'}} 
                        type="checkbox" 
                        name="isOpen" 
                        checked={isOpen} 
                        onChange={e=>setIsOpen(e.target.checked)} />
                </div>
                <button onClick={() => navigate('/')} style={{ margin: '10px' }}>Cancel</button>
                <button type="submit" style={{ margin: '10px' }}>Submit</button>
                {
                    errors.map((eachErr, idx) => (
                        <p key={idx} style={{ color: "red" }}>
                            {eachErr}
                        </p>
                    ))
                }
            </form>
        </div>


    )
}

export default CreateForm