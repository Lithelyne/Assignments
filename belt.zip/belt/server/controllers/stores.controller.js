const Stores = require("../models/stores.model")

//Get All
module.exports.allStores = (req, res) => {
    Stores.find()
        .then(storesList => res.json(storesList))
        .catch(err=>res.status(400).json(err))
}

//Get One
module.exports.oneStores = (req, res) => {
    Stores.findOne({_id: req.params.id})
        .then(foundStores=>res.json(foundStores))
        .catch(err=>res.status(400).json(err))
}

//Create
module.exports.addStores = (req, res) => {
    Stores.create(req.body)
        .then(newStores => res.json(newStores))
        .catch(err=>res.status(400).json(err))
}

//Update 
module.exports.updateStores = (req, res) => {
    Stores.findOneAndUpdate(
        {_id: req.params.id},
        req.body,
        {new: true, runValidators:true}
    )
        .then(updatedStores => res.json(updatedStores))
        .catch(err=>res.status(400).json(err))
}


//Delete
module.exports.deleteStores = (req, res) => {
    Stores.deleteOne({_id: req.params.id})
        .then(status=> res.json(status))
        .catch(err=>res.status(400).json(err))
}