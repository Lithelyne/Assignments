const StoresController = require("../controllers/stores.controller")

module.exports = (app) => {
    app.get("/api/stores", StoresController.allStores)
    app.get("/api/stores/:id", StoresController.oneStores)
    app.post("/api/stores", StoresController.addStores)
    app.patch("/api/stores/:id", StoresController.updateStores)
    app.delete("/api/stores/:id", StoresController.deleteStores)
}