const mongoose = require("mongoose");


const StoresSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Store name must contain at least 3 characters."],
        minlength: [3, "Store name must contain at least 3 characters"],
    },
    number: {
        type: Number,
        required: [true, "Store number must be greater then zero"],
        minlength: [1, "Number must be greater then zero"]
    },
    //check if actually number
    isOpen: {
        type: Boolean,
        default: false
    }
    

}, {timestamps : true})

module.exports = mongoose.model('Stores', StoresSchema)