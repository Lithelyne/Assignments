import './App.css';
import FetchPokemon from './components/FetchPokemon'

function App() {
  return (
    <div className="App">
      <FetchPokemon />
    </div>
  );
}

export default App;
